subdir('mate-panel-applet')
