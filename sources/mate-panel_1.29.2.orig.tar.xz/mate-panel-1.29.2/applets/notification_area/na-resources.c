#include <gio/gio.h>

#if defined (__ELF__) && ( __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 6))
# define SECTION __attribute__ ((section (".gresource.na"), aligned (sizeof(void *) > 8 ? sizeof(void *) : 8)))
#else
# define SECTION
#endif

static const SECTION union { const guint8 data[2069]; const double alignment; void * const ptr;}  na_resource_data = {
  "\107\126\141\162\151\141\156\164\000\000\000\000\000\000\000\000"
  "\030\000\000\000\000\001\000\000\000\000\000\050\010\000\000\000"
  "\000\000\000\000\002\000\000\000\004\000\000\000\004\000\000\000"
  "\006\000\000\000\007\000\000\000\010\000\000\000\010\000\000\000"
  "\000\113\055\223\002\000\000\000\000\001\000\000\006\000\114\000"
  "\010\001\000\000\014\001\000\000\350\136\053\125\005\000\000\000"
  "\014\001\000\000\047\000\166\000\070\001\000\000\104\007\000\000"
  "\201\321\040\031\004\000\000\000\104\007\000\000\005\000\114\000"
  "\114\007\000\000\120\007\000\000\341\367\354\015\005\000\000\000"
  "\120\007\000\000\032\000\166\000\160\007\000\000\352\007\000\000"
  "\113\120\220\013\006\000\000\000\352\007\000\000\004\000\114\000"
  "\360\007\000\000\364\007\000\000\063\005\100\241\007\000\000\000"
  "\364\007\000\000\003\000\114\000\370\007\000\000\000\010\000\000"
  "\324\265\002\000\377\377\377\377\000\010\000\000\001\000\114\000"
  "\004\010\000\000\010\010\000\000\265\144\045\040\000\000\000\000"
  "\010\010\000\000\007\000\114\000\020\010\000\000\024\010\000\000"
  "\160\141\156\145\154\057\000\000\007\000\000\000\156\157\164\151"
  "\146\151\143\141\164\151\157\156\055\141\162\145\141\055\160\162"
  "\145\146\145\162\145\156\143\145\163\055\144\151\141\154\157\147"
  "\056\165\151\000\000\000\000\000\336\034\000\000\001\000\000\000"
  "\170\332\325\131\155\163\233\070\020\376\316\257\330\343\123\073"
  "\027\342\330\235\266\067\115\342\216\233\326\251\147\222\064\023"
  "\073\323\311\047\106\200\000\065\102\342\044\141\307\367\353\157"
  "\001\307\057\005\233\340\346\332\353\247\140\330\147\265\373\150"
  "\337\244\234\274\177\110\070\114\251\322\114\212\123\273\173\170"
  "\144\003\025\276\014\230\210\116\355\333\311\320\371\313\176\337"
  "\267\116\376\160\034\070\247\202\052\142\150\000\063\146\142\210"
  "\070\011\050\274\072\354\365\016\273\140\131\011\176\161\122\042"
  "\050\007\007\212\277\116\252\144\112\225\141\124\073\001\043\134"
  "\106\326\231\114\347\212\105\261\201\027\147\057\341\022\041\360"
  "\221\116\051\317\345\054\153\022\063\015\010\212\024\111\000\037"
  "\103\105\051\150\031\232\031\121\364\030\346\062\003\237\010\120"
  "\064\140\332\050\346\145\010\147\006\210\010\072\122\131\011\032"
  "\035\316\363\027\231\010\250\002\023\123\060\124\045\032\144\130"
  "\374\070\277\272\135\370\300\341\072\363\070\363\341\202\371\124"
  "\150\152\021\134\067\177\243\143\364\316\233\027\342\303\174\365"
  "\361\142\165\030\112\324\112\014\262\164\014\024\335\307\005\026"
  "\254\101\317\132\054\260\320\166\000\122\301\013\142\162\203\025"
  "\310\064\007\275\104\053\347\300\321\341\045\356\260\352\360\312"
  "\257\000\230\050\164\306\110\015\076\240\066\164\154\306\070\007"
  "\217\102\246\151\230\361\003\013\045\341\353\150\362\371\313\355"
  "\004\006\127\167\360\165\160\163\063\270\232\334\035\027\073\044"
  "\361\053\222\133\352\141\111\312\131\276\165\104\051\042\314\034"
  "\111\261\056\077\335\234\175\106\371\301\207\321\305\150\162\227"
  "\233\075\034\115\256\076\215\307\060\374\162\003\003\270\036\334"
  "\114\106\147\267\027\203\033\270\276\275\271\376\062\376\164\010"
  "\060\246\271\101\324\332\116\047\204\250\051\221\310\132\100\015"
  "\141\134\243\253\167\270\171\032\115\342\001\304\144\112\161\023"
  "\175\312\246\150\020\001\037\203\342\051\173\304\245\210\312\320"
  "\063\153\274\035\003\013\101\110\163\000\063\305\060\040\214\254"
  "\356\236\265\332\275\003\030\011\377\360\000\136\167\121\204\210"
  "\173\216\074\217\015\012\243\202\041\013\121\371\220\113\251\016"
  "\340\203\324\046\027\277\034\000\034\365\272\335\043\247\373\352"
  "\250\173\000\267\343\001\272\063\310\220\137\365\016\276\112\036"
  "\106\004\355\272\345\236\142\176\154\131\216\203\351\302\004\156"
  "\164\110\174\332\267\000\116\024\375\073\143\212\152\340\314\073"
  "\265\043\163\377\247\275\112\271\074\201\354\116\041\227\047\331"
  "\022\351\360\322\157\307\314\061\002\242\224\117\173\220\353\256"
  "\310\011\222\120\130\317\276\072\241\200\152\137\261\042\024\267"
  "\045\147\075\320\137\146\354\146\266\326\113\223\202\026\135\241"
  "\345\121\132\172\337\250\157\300\347\104\353\123\373\334\334\017"
  "\202\157\231\066\011\025\306\006\026\234\332\144\371\273\153\347"
  "\010\304\054\014\235\103\356\350\251\315\345\214\052\273\377\366"
  "\244\363\370\241\136\056\113\323\134\256\173\164\324\044\071\045"
  "\074\243\166\277\367\246\111\120\033\232\272\114\370\212\026\006"
  "\367\273\115\200\224\104\164\007\340\244\123\362\121\117\315\050"
  "\101\164\311\012\313\037\267\021\062\145\232\171\034\035\230\250"
  "\214\066\131\204\365\323\015\245\237\151\273\077\044\134\067\312"
  "\063\137\012\067\177\264\373\063\046\002\071\163\174\056\277\207"
  "\355\366\343\143\021\135\245\043\230\247\054\144\176\221\211\056"
  "\046\046\161\123\105\103\252\260\345\120\355\226\161\150\077\217"
  "\345\236\124\330\005\334\031\013\114\154\367\137\067\211\033\146"
  "\220\103\060\130\023\064\226\151\202\214\236\332\163\212\253\135"
  "\255\331\014\003\264\031\256\127\066\067\251\305\254\147\377\220"
  "\142\173\236\144\165\111\262\233\112\315\362\365\354\076\326\000"
  "\114\256\106\353\261\106\270\061\313\143\254\044\261\002\360\143"
  "\306\203\362\071\207\163\314\326\130\162\144\250\263\020\350\254"
  "\111\224\322\145\136\013\302\235\342\047\106\232\047\037\354\245"
  "\216\312\106\177\300\257\305\056\227\046\070\033\342\055\343\166"
  "\237\010\250\303\110\305\220\100\122\162\071\315\353\235\117\370"
  "\123\200\072\045\076\316\100\130\026\152\245\353\011\042\376\062"
  "\260\327\034\257\345\052\063\330\135\276\147\154\033\176\017\362"
  "\366\045\260\032\054\115\116\224\036\024\145\301\053\137\174\217"
  "\254\051\342\304\243\274\066\333\334\263\152\175\331\255\353\111"
  "\124\064\320\321\026\032\023\275\057\064\137\065\240\041\311\270"
  "\151\017\136\114\115\172\245\141\347\106\326\126\364\242\255\364"
  "\313\226\322\006\210\103\247\133\114\326\070\062\065\262\275\336"
  "\022\066\225\022\377\036\363\252\171\071\372\200\163\112\260\207"
  "\203\041\016\311\173\300\126\045\267\273\313\255\132\373\067\212"
  "\347\166\002\352\235\337\313\361\075\234\256\016\047\376\275\233"
  "\067\016\273\117\105\360\144\324\222\246\243\172\110\015\105\025"
  "\172\252\005\246\132\134\260\355\122\117\312\373\345\340\120\376"
  "\372\157\313\142\033\130\303\200\261\265\261\304\330\337\261\342"
  "\351\226\333\125\340\312\065\237\251\174\237\053\026\224\354\106"
  "\345\211\313\215\362\067\077\247\342\266\316\317\204\250\210\011"
  "\227\323\020\253\336\233\075\220\305\051\146\077\250\221\351\176"
  "\100\117\142\103\114\132\142\025\156\364\162\374\150\205\364\045"
  "\317\022\261\002\167\173\073\321\265\161\122\037\053\027\145\303"
  "\316\203\045\101\277\212\143\001\116\266\324\055\073\171\235\222"
  "\037\210\233\037\215\235\372\226\315\131\204\145\113\033\242\114"
  "\133\360\216\171\345\222\011\226\144\011\214\220\022\030\043\045"
  "\357\332\052\157\325\130\267\204\233\240\211\024\314\317\253\121"
  "\104\061\312\067\067\111\247\114\354\126\271\255\137\357\356\331"
  "\265\124\141\202\272\304\030\342\307\133\173\304\166\064\146\332"
  "\123\301\133\172\361\226\176\334\076\344\307\110\332\372\204\133"
  "\245\364\047\207\375\076\360\370\161\232\330\007\154\350\203\251"
  "\015\372\336\233\266\252\126\367\072\166\177\355\216\247\065\033"
  "\234\045\236\233\137\102\357\034\323\352\301\042\113\250\142\376"
  "\176\134\154\275\044\372\051\171\324\375\215\363\150\167\353\160"
  "\123\366\100\271\376\035\072\310\366\046\120\372\360\113\042\243"
  "\367\277\212\214\172\047\153\205\027\127\050\371\001\004\215\042"
  "\236\135\075\052\126\056\251\236\240\360\171\264\074\233\131\277"
  "\344\030\330\346\024\323\170\354\155\076\317\155\372\270\171\221"
  "\130\336\150\071\345\130\242\227\210\215\327\240\250\116\245\320"
  "\150\215\363\326\356\257\335\044\235\164\066\004\037\027\250\052"
  "\135\231\160\322\131\373\337\313\277\162\270\242\237\000\050\165"
  "\165\141\171\051\155\141\164\145\057\000\000\000\000\000\000\000"
  "\156\157\164\151\146\151\143\141\164\151\157\156\055\141\162\145"
  "\141\055\155\145\156\165\056\170\155\154\000\000\000\000\000\000"
  "\351\000\000\000\001\000\000\000\170\332\263\311\115\315\053\315"
  "\054\111\315\125\310\113\314\115\265\125\362\313\057\311\114\313"
  "\114\116\054\311\314\317\123\160\054\112\115\124\010\050\112\115"
  "\113\055\112\315\113\116\055\126\360\004\052\124\122\110\114\006"
  "\311\332\052\005\127\026\003\371\041\105\211\225\110\152\224\024"
  "\364\355\270\154\010\232\352\221\232\123\200\323\070\220\044\221"
  "\346\070\046\345\227\226\340\064\010\054\013\066\211\013\000\101"
  "\256\122\033\000\050\165\165\141\171\051\157\162\147\057\000\000"
  "\002\000\000\000\156\141\057\000\003\000\000\000\001\000\000\000"
  "\057\000\000\000\004\000\000\000\141\160\160\154\145\164\057\000"
  "\005\000\000\000" };

static GStaticResource static_resource = { na_resource_data.data, sizeof (na_resource_data.data) - 1 /* nul terminator */, NULL, NULL, NULL };

G_MODULE_EXPORT
GResource *na_get_resource (void);
GResource *na_get_resource (void)
{
  return g_static_resource_get_resource (&static_resource);
}
/* GLIB - Library of useful routines for C programming
 * Copyright (C) 1995-1997  Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Modified by the GLib Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GLib Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GLib at ftp://ftp.gtk.org/pub/gtk/.
 */

#ifndef __G_CONSTRUCTOR_H__
#define __G_CONSTRUCTOR_H__

/*
  If G_HAS_CONSTRUCTORS is true then the compiler support *both* constructors and
  destructors, in a usable way, including e.g. on library unload. If not you're on
  your own.

  Some compilers need #pragma to handle this, which does not work with macros,
  so the way you need to use this is (for constructors):

  #ifdef G_DEFINE_CONSTRUCTOR_NEEDS_PRAGMA
  #pragma G_DEFINE_CONSTRUCTOR_PRAGMA_ARGS(my_constructor)
  #endif
  G_DEFINE_CONSTRUCTOR(my_constructor)
  static void my_constructor(void) {
   ...
  }

*/

#ifndef __GTK_DOC_IGNORE__

#if  __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 7)

#define G_HAS_CONSTRUCTORS 1

#define G_DEFINE_CONSTRUCTOR(_func) static void __attribute__((constructor)) _func (void);
#define G_DEFINE_DESTRUCTOR(_func) static void __attribute__((destructor)) _func (void);

#elif defined (_MSC_VER)

/*
 * Only try to include gslist.h if not already included via glib.h,
 * so that items using gconstructor.h outside of GLib (such as
 * GResources) continue to build properly.
 */
#ifndef __G_LIB_H__
#include "gslist.h"
#endif

#include <stdlib.h>

#define G_HAS_CONSTRUCTORS 1

/* We do some weird things to avoid the constructors being optimized
 * away on VS2015 if WholeProgramOptimization is enabled. First we
 * make a reference to the array from the wrapper to make sure its
 * references. Then we use a pragma to make sure the wrapper function
 * symbol is always included at the link stage. Also, the symbols
 * need to be extern (but not dllexport), even though they are not
 * really used from another object file.
 */

/* We need to account for differences between the mangling of symbols
 * for x86 and x64/ARM/ARM64 programs, as symbols on x86 are prefixed
 * with an underscore but symbols on x64/ARM/ARM64 are not.
 */
#ifdef _M_IX86
#define G_MSVC_SYMBOL_PREFIX "_"
#else
#define G_MSVC_SYMBOL_PREFIX ""
#endif

#define G_DEFINE_CONSTRUCTOR(_func) G_MSVC_CTOR (_func, G_MSVC_SYMBOL_PREFIX)
#define G_DEFINE_DESTRUCTOR(_func) G_MSVC_DTOR (_func, G_MSVC_SYMBOL_PREFIX)

#define G_MSVC_CTOR(_func,_sym_prefix) \
  static void _func(void); \
  extern int (* _array ## _func)(void);              \
  int _func ## _wrapper(void);              \
  int _func ## _wrapper(void) { _func(); g_slist_find (NULL,  _array ## _func); return 0; } \
  __pragma(comment(linker,"/include:" _sym_prefix # _func "_wrapper")) \
  __pragma(section(".CRT$XCU",read)) \
  __declspec(allocate(".CRT$XCU")) int (* _array ## _func)(void) = _func ## _wrapper;

#define G_MSVC_DTOR(_func,_sym_prefix) \
  static void _func(void); \
  extern int (* _array ## _func)(void);              \
  int _func ## _constructor(void);              \
  int _func ## _constructor(void) { atexit (_func); g_slist_find (NULL,  _array ## _func); return 0; } \
   __pragma(comment(linker,"/include:" _sym_prefix # _func "_constructor")) \
  __pragma(section(".CRT$XCU",read)) \
  __declspec(allocate(".CRT$XCU")) int (* _array ## _func)(void) = _func ## _constructor;

#elif defined(__SUNPRO_C)

/* This is not tested, but i believe it should work, based on:
 * http://opensource.apple.com/source/OpenSSL098/OpenSSL098-35/src/fips/fips_premain.c
 */

#define G_HAS_CONSTRUCTORS 1

#define G_DEFINE_CONSTRUCTOR_NEEDS_PRAGMA 1
#define G_DEFINE_DESTRUCTOR_NEEDS_PRAGMA 1

#define G_DEFINE_CONSTRUCTOR_PRAGMA_ARGS(_func) \
  init(_func)
#define G_DEFINE_CONSTRUCTOR(_func) \
  static void _func(void);

#define G_DEFINE_DESTRUCTOR_PRAGMA_ARGS(_func) \
  fini(_func)
#define G_DEFINE_DESTRUCTOR(_func) \
  static void _func(void);

#else

/* constructors not supported for this compiler */

#endif

#endif /* __GTK_DOC_IGNORE__ */
#endif /* __G_CONSTRUCTOR_H__ */

#ifdef G_HAS_CONSTRUCTORS

#ifdef G_DEFINE_CONSTRUCTOR_NEEDS_PRAGMA
#pragma G_DEFINE_CONSTRUCTOR_PRAGMA_ARGS(naresource_constructor)
#endif
G_DEFINE_CONSTRUCTOR(naresource_constructor)
#ifdef G_DEFINE_DESTRUCTOR_NEEDS_PRAGMA
#pragma G_DEFINE_DESTRUCTOR_PRAGMA_ARGS(naresource_destructor)
#endif
G_DEFINE_DESTRUCTOR(naresource_destructor)

#else
#warning "Constructor not supported on this compiler, linking in resources will not work"
#endif

static void naresource_constructor (void)
{
  g_static_resource_init (&static_resource);
}

static void naresource_destructor (void)
{
  g_static_resource_fini (&static_resource);
}
